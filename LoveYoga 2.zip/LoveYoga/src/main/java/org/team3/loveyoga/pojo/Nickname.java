package org.team3.loveyoga.pojo;

public class Nickname {
    private Integer nickNameId;

    private String nickname;

    private Integer flag;

    public Integer getNicknameid() {
        return nickNameId;
    }

    public void setNicknameid(Integer nicknameid) {
        this.nickNameId = nicknameid;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }
}