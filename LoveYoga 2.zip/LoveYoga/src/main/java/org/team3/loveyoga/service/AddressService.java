package org.team3.loveyoga.service;

import org.team3.loveyoga.pojo.Coach;

public interface AddressService {

	boolean setAddress(Coach coach);

	
}
